<?php
echo "hola mundo";
phpinfo();
?>